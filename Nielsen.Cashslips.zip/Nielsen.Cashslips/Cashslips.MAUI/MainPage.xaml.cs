﻿using System.Collections.Generic;

using System.Threading.Tasks; 
using System;
using System.Globalization; 
using Cashslips.MAUI;

namespace Cashslips.Forms
{
    public partial class MainPage : ContentPage 
    {
     

        private bool isNeedToShowHomePage = false;
        private bool isAuthStarted = false;

        public MainPage()
        { 
           
            InitializeComponent(); 
             
        }

        protected override void OnAppearing()
        {
             
            base.OnAppearing();
        }

        protected override bool OnBackButtonPressed()
        {
            System.Diagnostics.Process.GetCurrentProcess().CloseMainWindow();
            return base.OnBackButtonPressed();
        }

       
    }
}
