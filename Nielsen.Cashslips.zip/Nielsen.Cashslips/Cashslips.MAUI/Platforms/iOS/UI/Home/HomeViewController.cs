﻿using System;
using System.Collections.Generic;
using System.Linq;
using CoreGraphics;
using Foundation;   
using UIKit;  
namespace Nielsen.iOS
{
    public partial class HomeViewController : UIViewController
    {
        private readonly UIColor blackDisabledColor = UIColor.FromName("black_disabled");
        
        private UIImageView bellImageView;
        private UITapGestureRecognizer syncViewGesture = new UITapGestureRecognizer();
        private UIBarButtonItem errorButton, networkredicon;
        private bool isAppInitialLaunch = true; 

        public static bool isSyncBackPressed = false;
        
        public bool IsUserLogged = true;
        bool isNetworkwarningShown = false;
        public HomeViewController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            this.View.BackgroundColor = UIColor.FromName("light_gray");
            

            
        }

        
    }
}
