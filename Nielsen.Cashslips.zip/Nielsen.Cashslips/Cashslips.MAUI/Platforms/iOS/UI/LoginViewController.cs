using System;
using CoreAnimation;
using CoreGraphics;
using Foundation;
using Nielsen.Core;
using Nielsen.Logger;
using Nielsen.Sync;
using UIKit;

namespace Nielsen.iOS
{
	public partial class LoginViewController : UIViewController
	{
        public const string APP_KEY_PROD = "acd340e8-3544-4f18-9966-9e6b606507fe";
        public const string APP_KEY_UAT = "a28ab0ad-e870-40a2-8400-cb0422188c13";

        private readonly UIImage eyeIcon = UIImage.FromBundle("ic_eye");
        private readonly UIImage eyeIconHide = UIImage.FromBundle("ic_eye_hide");
        private readonly UIImage errorIcon = UIImage.FromBundle("ic_error");

        private readonly UIColor splashGreen = UIColor.FromName("splash_green");
        private readonly UIColor errorColor = UIColor.FromName("error_color");
        private readonly UIColor blackDisabledColor = UIColor.FromName("black_disabled");

        private NSObject keyboardWillShowNotificationObserver;
        private NSObject keyboardWillHideNotificationObserver;
        private bool isLoginProccessed;
        private INetworkReachability networkReachability = new Reachability();
        private string currentLogin;
        private string currentPassword;
        private bool isError = false;
        private bool isPasswordHidden = true;
        private CALayer passwordBottomBorder;
        private CALayer auditorIdBottomBorder;

        public LoginViewController (IntPtr handle) : base (handle)
		{
		}

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            InitializeComponents();
            var version = NSBundle.MainBundle.InfoDictionary.ObjectForKey(new NSString("CFBundleShortVersionString")) as NSString;
            var appName = NSBundle.MainBundle.InfoDictionary.ObjectForKey(new NSString("CFBundleDisplayName")) as NSString;
            appVersionLabel.Text = string.Format("{0} {1} {2}", appName, Utilities.LocalizedString("ver"), version);
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);

            if (isLoginProccessed)
            {
                ShowIndicator();
            }
            else
            {
                HideIndicator();
            }
        }

        public override void ViewWillDisappear(bool animated)
        {
            base.ViewWillDisappear(animated);
        }

        public override void PrepareForSegue(UIStoryboardSegue segue, NSObject sender)
        {
            if (segue.Identifier.Equals("ShowAppLicenseViewController"))
            {
                currentLogin = loginTextField.Text;
                currentPassword = passwordTextField.Text;
                var appLicenseViewController = (AppLicenseViewController)segue.DestinationViewController;
                appLicenseViewController.AppLicenseSelected += HandleAppLicenseSelected;
            }
        }

        private void HandleKeyboardWillShowNotification(object sender, UIKeyboardEventArgs e)
        {
            var r = UIKeyboard.FrameBeginFromNotification(e.Notification);
            var keyboardHeight = r.Height;

            var space = inputDataView.Frame.Top - (View.Frame.Height - keyboardHeight - 30);
            if (space > 0)
            {
                UIView.BeginAnimations(string.Empty, IntPtr.Zero);
                UIView.SetAnimationDuration(0.1);

                UIView.CommitAnimations();
            }
        }

        private void HandleKeyboardWillHideNotification(object sender, UIKeyboardEventArgs e)
        {
            UIView.BeginAnimations(string.Empty, IntPtr.Zero);
            UIView.SetAnimationDuration(0.1);

            UIView.CommitAnimations();
        }

        private void InitializeComponents()
        {
            var tap = new UITapGestureRecognizer { CancelsTouchesInView = false };
            tap.AddTarget(() => View.EndEditing(true));
            View.AddGestureRecognizer(tap);

            titleLabel.Text = Utilities.LocalizedString("login");

            loginButton.SetTitle(Utilities.LocalizedString("login"), UIControlState.Normal);
            loginButton.Enabled = false;
            Utilities.InitBlackButton(loginButton);
            loginButton.BackgroundColor = UIColor.Black.ColorWithAlpha(0.5f);
            passwordBottomBorder = new CALayer();
            passwordBottomBorder.Frame = new CGRect(0, passwordTextField.Frame.Height - 1, 400, passwordTextField.Frame.Height);
            passwordBottomBorder.BackgroundColor = UIColor.Black.CGColor;
            passwordTextField.Layer.AddSublayer(passwordBottomBorder);
            passwordTextField.Layer.MasksToBounds = true;

            auditorIdBottomBorder = new CALayer();
            auditorIdBottomBorder.Frame = new CGRect(0, loginTextField.Frame.Height - 1, 400, loginTextField.Frame.Height);
            auditorIdBottomBorder.BackgroundColor = UIColor.Black.CGColor;
            loginTextField.Layer.AddSublayer(auditorIdBottomBorder);
            loginTextField.Layer.MasksToBounds = true;

            Utilities.SetDoneButtonForKeyboard(loginTextField);
            Utilities.SetDoneButtonForKeyboard(passwordTextField);

            auditorIdLabel.Text = Utilities.LocalizedString("auditorid");
            passwordLabel.Text = Utilities.LocalizedString("password");
            passwordTextField.SecureTextEntry = true;

            loginTextField.EditingChanged += HandleLoginAndPasswordChanged;
            passwordTextField.EditingChanged += HandleLoginAndPasswordChanged;
            loginTextField.EditingDidBegin += ((sender, e) =>
            {
                if (isError)
                {
                    SetErrorState(false);
                }
                auditorIdBottomBorder.BackgroundColor = splashGreen.CGColor;
            });
            loginTextField.EditingDidEnd += ((sender, e) =>
            {
                auditorIdBottomBorder.BackgroundColor = UIColor.Black.CGColor;
            });

            passwordTextField.EditingDidBegin += ((sender, e) =>
            {
                if (isError)
                {
                    SetErrorState(false);
                }
                passwordBottomBorder.BackgroundColor = splashGreen.CGColor;
            });
            passwordTextField.EditingDidEnd += ((sender, e) =>
            {
                passwordBottomBorder.BackgroundColor = UIColor.Black.CGColor;
            });

            errorMessageLabel.Text = Utilities.LocalizedString("login_error");
        }

        private void HandleLoginAndPasswordChanged(object sender, EventArgs e)
        {
            loginButton.Enabled = loginTextField.Text.Length > 0 && passwordTextField.Text.Length > 0;
            loginButton.BackgroundColor = loginButton.Enabled ? UIColor.Black : blackDisabledColor;
        }

        private void SetErrorState(bool state)
        {
            isError = state;
            InvokeOnMainThread(() =>
            {
                passwordBottomBorder.BackgroundColor = isError ? errorColor.CGColor : UIColor.Black.CGColor;
                auditorIdBottomBorder.BackgroundColor = isError ? errorColor.CGColor : UIColor.Black.CGColor;
                errorMessageLabel.Hidden = !isError;
                passwordTextViewButton.SetImage(isError ? errorIcon : isPasswordHidden ? eyeIcon : eyeIconHide,
                    UIControlState.Normal);
                auditorIdTextViewButton.Hidden = !isError;
            });
        }

        private void HideIndicator()
        {
            InvokeOnMainThread(() =>
            {
                this.HideActivityIndicator();
            });
        }

        private void ShowIndicator()
        {
            InvokeOnMainThread(() =>
            {
                this.ShowActivityIndicator();
            });
        }

        private void HandleAppLicenseSelected(bool accepted)
        {
            if (!accepted)
            {
                HideIndicator();
                isLoginProccessed = false;
            }
            else
            {
                isLoginProccessed = true;
                if (networkReachability.GetNetworkStatus() != NetworkStatus.NotReachable)
                {
                    ShowIndicator();
                    PerformLogin(currentLogin, currentPassword);
                }
                else
                {
                    isLoginProccessed = false;
                    HideIndicator();
                    InvokeOnMainThread(() =>
                    {
                        ShowAlertDialog(true);
                    });
                }
            }
        }

        private void PerformLogin(string login, string password)
        {
            isLoginProccessed = true;
            var syncUtil = new SyncUtil(login, password);
            LoggerHandler.InsertLog(LoggerHandler.INFORMAL_LOG, "[CSSIapp][LoginScreen]: User is trying to log in.");
            syncUtil.SendLoginRequest(() =>
            {
                isLoginProccessed = false;
                NSUserDefaults.StandardUserDefaults.SetString(login, Constants.AUDITOR_ID_KEY);
                NSUserDefaults.StandardUserDefaults.SetString(password, Constants.PASSWORD_KEY);
                NSUserDefaults.StandardUserDefaults.SetString(syncUtil.currentUploadUrl, Constants.URL_KEY);

                string appCenterKey = string.Equals(syncUtil.currentUploadUrl, SyncUtil.PROD_UPLOAD_URL)
                    ? APP_KEY_PROD
                    : APP_KEY_UAT;
                NSUserDefaults.StandardUserDefaults.SetString(appCenterKey, Constants.APP_CENTER_KEY);
                Utilities.StartAppCenter();

                InitTransmitter(login, password, string.IsNullOrEmpty(syncUtil.currentUploadUrl) ? Constants.defUrl : syncUtil.currentUploadUrl);
                ShowHomeViewController();
            },
           (Exception e) =>
           {
               LoggerHandler.InsertLog(LoggerHandler.EXCEPTION_LOG, "[CSSIapp][LoginScreen]: User can not log in." + e.Message + "has been caught.");
               
               Console.WriteLine(e);
               HideIndicator();
               if (isLoginProccessed)
               {
                   SetErrorState(true);
               }
               isLoginProccessed = false;
           });
        }

        private void InitTransmitter(string login, string password, string uploadUrl)
        {
            var reportTransmitter = new ReportTransmitter(password, login, uploadUrl, Utilities.GetDeviceData());
            AppDelegate.Instance.ReportTransmitter = reportTransmitter;
        }

        private void ShowAlertDialog(bool networkNotReachable = false)
        {
            InvokeOnMainThread(() =>
            {
                var alert = UIAlertController.Create(Utilities.LocalizedString("login_failed"), null, UIAlertControllerStyle.Alert);
                alert.AddAction(UIAlertAction.Create(Utilities.LocalizedString("ok"), UIAlertActionStyle.Default, null));
                alert.View.TintColor = UIColor.Black;
                PresentViewController(alert, true, null);
            });
        }

        private void ShowHomeViewController()
        {
            InvokeOnMainThread(() =>
            {
                loginTextField.EditingChanged -= HandleLoginAndPasswordChanged;
                passwordTextField.EditingChanged -= HandleLoginAndPasswordChanged;
                HideIndicator();
                var homeVC = Storyboard.InstantiateViewController(@"HomeViewController") as HomeViewController;
                var navCtrl = new UINavigationController(homeVC);
                navCtrl.ModalPresentationStyle = UIModalPresentationStyle.FullScreen;
                Utilities.SetUpNavigationBar(navCtrl.NavigationBar);
                PresentViewController(navCtrl, false, null);
            });
        }

        partial void OnShowHidePasswordClicked(UIButton sender)
        {
            if (!isError)
            {
                UIImage icon = null;
                if (isPasswordHidden)
                {
                    icon = eyeIconHide;
                    passwordTextField.SecureTextEntry = false;
                    passwordTextField.Font = null;
                    passwordTextField.Font = loginTextField.Font;
                    passwordTextField.LayoutIfNeeded();
                    isPasswordHidden = false;
                }
                else
                {
                    icon = eyeIcon;
                    passwordTextField.SecureTextEntry = true;
                    isPasswordHidden = true;
                }
                passwordTextViewButton.SetImage(icon, UIControlState.Normal);
                passwordTextViewButton.SetImage(icon.ApplyTintColor(splashGreen), UIControlState.Focused);
                passwordTextViewButton.SetImage(icon.ApplyTintColor(splashGreen), UIControlState.Highlighted);
                passwordTextViewButton.SetImage(icon.ApplyTintColor(splashGreen), UIControlState.Selected);
            }
        }
    }
}
