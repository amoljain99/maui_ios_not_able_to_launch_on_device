﻿using System;
using System.Threading.Tasks; 
using UIKit;   
using Cashslips.MAUI;
using Foundation;

namespace Nielsen.iOS
{
    // The UIApplicationDelegate for the application. This class is responsible for launching the
    // User Interface of the application, as well as listening (and optionally responding) to application events from iOS.
    [Register("AppDelegate")]
    public class AppDelegate : MauiUIApplicationDelegate
    {
        public static AppDelegate Instance => UIApplication.SharedApplication.Delegate as AppDelegate;

      
        public bool IsStartedFromNotification = false;

        public override UIWindow Window
        {
            get;
            set;
        }

   
        protected override MauiApp CreateMauiApp()
        {
            
            return MauiProgram.CreateMauiApp();
        }



        public nint RegisterBackgroundTask(Action expirationHandler)
        {
            return UIApplication.SharedApplication.BeginBackgroundTask(() => expirationHandler?.Invoke());
        }

        public void UnregisterBackgroundTask(nint backgroundTaskId)
        {
            UIApplication.SharedApplication.EndBackgroundTask(backgroundTaskId);
        }

         
 
    }

   
}

