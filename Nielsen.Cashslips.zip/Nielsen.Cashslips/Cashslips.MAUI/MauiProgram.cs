﻿
using Microsoft.Extensions.Logging;
using Microsoft.Maui.Controls.Compatibility.Hosting;  

namespace Cashslips.MAUI
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder()
                .UseMauiApp<App>()
                .UseMauiCompatibility();
//#if ANDROID
//                .UseSharedDroidMauiApp();           // from Widgets.Android, registers renderers and effects 
//#endif 
#if DEBUG
            builder.Logging.AddDebug();
#endif 
            return builder.Build(); 
        }
    }
}